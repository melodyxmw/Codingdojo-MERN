import React from 'react';

const Content = (props) => {
    return (
        <div>{props.displayText}</div>
    )
}

export default Content;
